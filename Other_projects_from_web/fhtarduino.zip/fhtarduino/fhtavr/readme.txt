Notes on use

1. Wire rfm22/23 to arduino as per Mike's spec.
2. Power up radiator valve, and after initial whir, click button once - wait for valve to calibrate.
3. Press and hold button for 3 seconds.
4. From serial console (19200) - REMEMBER TO SET NEWLINE as line terminator, send 
fht pair hc1 hc2
where hc1 and hc2 are appropriate house codes - e.g. 10 11
5. valve should now be synced. try sending beep
fht beep
wait upto 2 minutes for time slot to come around.
6. re-sync if for any reason ATMEGA resets, need to resync valve. send
fht sync hc1 hc2
where hc1 and hc2 are the original values used to pair
  