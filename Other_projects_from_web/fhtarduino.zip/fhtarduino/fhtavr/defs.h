#define strcmp_PF strcmp_P
#define DEBUG 1
#define __AVR_ATmega328__

