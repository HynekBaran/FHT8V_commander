/*!
 * FHT heating valve comms example with RFM22/23 for AVR
 *
 * Copyright (C) 2013 Mike Stirling
 *
 * The OpenTRV project licenses this file to you
 * under the Apache Licence, Version 2.0 (the "Licence");
 * you may not use this file except in compliance
 * with the Licence. You may obtain a copy of the Licence at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the Licence for the
 * specific language governing permissions and limitations
 * under the Licence.
 *
 * \file fht.h
 * \brief FHT protocol implementation for RFM22/23
 *
 * This is an implementation of the FHT8V valve protocol for SiLabs
 * EzRadioPro devices such as found on HopeRF RFM22 and RFM23 modules.
 *
 * It is not extensively tested and is primarily a proof of concept.
 *
 */

#ifndef FHT_H_
#define FHT_H_

#define FHT_REPEAT			(1 << 7)
#define FHT_EXT_PRESENT		(1 << 5)
#define FHT_BATT_WARN		(1 << 4)

#define FHT_SYNC_SET		0
#define FHT_VALVE_OPEN		1
#define FHT_VALVE_CLOSE		2
#define FHT_VALVE_SET		6
#define FHT_OFFSET			8
#define FHT_DESCALE			10
#define FHT_SYNC			12
#define FHT_TEST			14

#define FHT_BROADCAST		0

typedef struct {
	uint8_t	hc1;
	uint8_t hc2;
	uint8_t address;
	uint8_t command;
	uint8_t extension;
	uint8_t checksum;
} __attribute__((packed)) fht_msg_t;

void fht_init(void);
void fht_tick(void);
void fht_enqueue(uint8_t address, uint8_t command, uint8_t value);
void fht_sync(uint8_t hc1, uint8_t hc2);
void fht_receive(void);

#endif /* FHT_H_ */
