/*
 * FHT heating valve comms example with RFM22/23 for AVR
 *
 * Copyright (C) 2013 Mike Stirling
 *
 * The OpenTRV project licenses this file to you
 * under the Apache Licence, Version 2.0 (the "Licence");
 * you may not use this file except in compliance
 * with the Licence. You may obtain a copy of the Licence at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the Licence for the
 * specific language governing permissions and limitations
 * under the Licence.
 *
 * \file main.c
 * \brief Top-level
 *
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/delay.h>
#include <avr/sleep.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "si443x_min.h"
#include "fht.h"
#include "cli.h"

#include "board.h"
#include "common.h"

/*************************************************/

/* 2 Hz tick */
#define SYSTEM_TICK		2

static volatile uint32_t g_tick_count;

/* Half second tick interrupt */
ISR(TIMER1_COMPA_vect)
{
	g_tick_count++;

	/* Run half-second FHT driver jobs */
	fht_tick();
}

uint32_t get_tick_count(void)
{
	uint32_t tick_count;

	/* Atomic copy */
	cli();
	tick_count = g_tick_count;
	sei();
	return tick_count;
}

/*************************************************/

/* Sync with a valve or set a command for transmission in the next
 * transmit window (which may be up to 2 minutes later) */
static int fht_handler(cli_t *ctx, void *arg, int argc, char **argv)
{
	uint8_t value;

	if (argc < 2)
		return 1;

	if (strcmp_PF(argv[1], PSTR("sync")) == 0) {
		uint8_t hc1, hc2;

		if (argc < 4)
			return 2;

		/* 'sync' takes two arguments which are the two house codes for
		 * the valve with which we are syncing e.g.
		 * > fht sync 12 34
		 */
		hc1 = atoi(argv[2]);
		hc2 = atoi(argv[3]);

		/* Initiate sync */
		DPRINTF("Syncing valve %d %d\n", hc1, hc2);
		fht_sync(hc1, hc2);
	} else if (strcmp_PF(argv[1], PSTR("set")) == 0) {
		if (argc < 3)
			return 1;

		/* 'set' takes one argument which is the valve position in the
		 * range 0 to 255 */
		value = atoi(argv[2]);

		DPRINTF("Setting valve to %u\n", value);
		fht_enqueue(0, FHT_VALVE_SET, value);
	} else if (strcmp_PF(argv[1], PSTR("beep")) == 0) {
		/* 'beep' will instruct the valve to make a beep */
		DPRINTF("Requesting valve test beep\n");
		fht_enqueue(0, FHT_TEST, 0);
	} else {
		return 1;
	}

	return 0;
}

static int fhtrx_handler(cli_t *ctx, void *arg, int argc, char **argv)
{
	DPRINTF("FHT test receiver started - reset to exit\n");

	/* Disable timer to inhibit transmitter */
	TIMSK1 = 0;

	while (1) {
		fht_receive();
	}
	return 0;
}

int main(void)
{
	uint8_t	mcustatus = MCUSR;

	MCUSR = 0;

	// Set up port directions and load initial values/enable pull-ups
	PORTB = PORTB_VAL;
	PORTC = PORTC_VAL;
	PORTD = PORTD_VAL;
	DDRB = DDRB_VAL;
	DDRC = DDRC_VAL;
	DDRD = DDRD_VAL;

#ifdef DEBUG
	debug_init();
#endif

	DPRINTF("\n\n"
			"FHT valve communication example for RFM22/23\n"
			"(C) 2013 Mike Stirling\n"
			"http://www.mikestirling.co.uk\n\n");

	DPRINTF("Debug level = %u\n", DEBUG);
	DPRINTF("System clock = %lu Hz\n", F_CPU);
	DPRINTF("Reset status = 0x%X\n", mcustatus);

	/* Configure tick interrupt for half second from internal
	 * 8 MHz clock using timer 1 */
	TCCR1A = 0; /* CTC mode */
	TCCR1B = _BV(WGM12) | _BV(CS12); /* divide by 256 */
	OCR1A = F_CPU / 256 / SYSTEM_TICK - 1;
	TIMSK1 = _BV(OCIE1A);

	sei();

	/* Turn on radio module */
	DPRINTF("Enabling radio...\n");
	TRX_ON();
	_delay_ms(30);
	if (si443x_init() < 0) {
		DPRINTF("FAILED (STOP)\n");
		while (1);
	}
	DPRINTF("OK\n\n");
	si443x_dump();

	/* Set up CLI */
	cli_init(stdin, stdout, PSTR("FHT demo"));
	cli_register_command(PSTR("fht"), fht_handler, NULL, PSTR("fht sync <hc1> <hc2>|set <pos>|beep"));
	cli_register_command(PSTR("fhtrx"), fhtrx_handler, NULL, PSTR("fhtrx - start receiver"));
	cli_task(); /* never returns */

	return 0;
}
