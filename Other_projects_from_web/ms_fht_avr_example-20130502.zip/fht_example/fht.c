/*
 * FHT heating valve comms example with RFM22/23 for AVR
 *
 * Copyright (C) 2013 Mike Stirling
 *
 * The OpenTRV project licenses this file to you
 * under the Apache Licence, Version 2.0 (the "Licence");
 * you may not use this file except in compliance
 * with the Licence. You may obtain a copy of the Licence at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the Licence for the
 * specific language governing permissions and limitations
 * under the Licence.
 *
 * \file fht.c
 * \brief FHT protocol implementation for RFM22/23
 *
 * This is an implementation of the FHT8V valve protocol for SiLabs
 * EzRadioPro devices such as found on HopeRF RFM22 and RFM23 modules.
 *
 * It is not extensively tested and is primarily a proof of concept.
 *
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdint.h>
#include <string.h>

#include "board.h"
#include "common.h"
#include "si443x_min.h"
#include "fht.h"

/*! Number of ticks to remain in sync mode (must be even) */
#define SYNC_TICKS		240
/*! Period (in ticks) for timeslot 0 - the period increases by
 * one tick for each higher slot */
#define PERIOD_BASE		230

static volatile fht_msg_t g_message;
static volatile uint8_t g_slot_count;
static volatile uint16_t g_ticks = 0;
static volatile uint8_t g_nbits;

static void msgdump(fht_msg_t *msg)
{
	int n;
	uint8_t *_msg = (uint8_t*)msg;
	uint8_t mychecksum;

	/* Calculate expected checksum */
	mychecksum = 0x0c;
	for (n = 0; n < 5; n++) {
		mychecksum += _msg[n];
	}

	printf_P(PSTR("Received message:\n"));
	printf_P(PSTR("HC1 = %hu, HC2 = %hu, ADDR = %hu\n"), msg->hc1, msg->hc2, msg->address);

	printf_P(PSTR("FLAGS: "));
	if (msg->command & FHT_REPEAT)
		printf_P(PSTR("REPEAT "));
	if (msg->command & FHT_EXT_PRESENT)
		printf_P(PSTR("EXTENDED "));
	if (msg->command & FHT_BATT_WARN)
		printf_P(PSTR("ENABLE_LOW_BATT_WARNING "));
	printf_P(PSTR("\n"));

	printf_P(PSTR("COMMAND: "));
	switch (msg->command & 0xf) {
	case FHT_SYNC_SET:
		printf_P(PSTR("SYNC_SET %hu\n"), msg->extension);
		break;
	case FHT_VALVE_OPEN:
		printf_P(PSTR("VALVE_OPEN\n"));
		break;
	case FHT_VALVE_CLOSE:
		printf_P(PSTR("VALVE_CLOSE\n"));
		break;
	case FHT_VALVE_SET:
		printf_P(PSTR("VALVE_SET %hu\n"), msg->extension);
		break;
	case FHT_OFFSET:
		printf_P(PSTR("OFFSET %hd\n"), msg->extension);
		break;
	case FHT_DESCALE:
		printf_P(PSTR("DESCALE\n"));
		break;
	case FHT_SYNC:
		printf_P(PSTR("SYNC %hu\n"), msg->extension);
		break;
	case FHT_TEST:
		printf_P(PSTR("TEST\n"));
		break;
	default:
		printf_P(PSTR("%hu %hu\n"), msg->command & 0xf, msg->extension);
	}

	if (msg->checksum == mychecksum) {
		printf_P(PSTR("Checksum OK\n"));
	} else {
		printf_P(PSTR("Checksum bad\n"));
	}
}

static void hexdump(uint8_t *buf, int size)
{
	int n;

	for (n = 0; n < size; n++) {
		if ((n & 15) == 0)
			printf_P(PSTR("0%X : "), n >> 4);
		if (buf[n] < 0x10)
			printf_P(PSTR("0")); /* deal with broken printf */
		printf_P(PSTR("%X "), buf[n]);
		if ((n & 15) == 15)
			printf_P(PSTR("\n"));
	}
	printf_P(PSTR("\n"));
}

/*
 * Takes another FHT protocol bit and encodes it into either
 * 1100 (for a 0) or 111000 (for a 1) and pushes it to the
 * transmitter output buffer.
 */
static void pushbit(int bit, uint8_t **outptr)
{
	static uint8_t byteval = 0;
	int size, shift;
	uint8_t mask;

	if (bit) {
		// 1 is 600us on/off - load 111000 to output
		size = 6;
		mask = 0x38;
	} else {
		// 0 is 400us on/off - load 1100 to output
		size = 4;
		mask = 0x0c;
	}

	while (size) {
		// shift to fit
		shift = (size > (8 - g_nbits)) ? (8 - g_nbits) : size;
		byteval = (byteval << shift) | (mask >> (size - shift));
		size -= shift;
		g_nbits += shift;
		if (g_nbits == 8) {
			*(*outptr) = byteval;
			(*outptr)++;
			g_nbits = 0;
		}
	}
}

/*!
 * Encode a buffer into a format that will generate
 * the FHT pulse-width encoding when transmitted.
 * Parity bit is added for each byte.
 */
static int fht_rfm_encode(uint8_t *inbuf, uint8_t *outbuf, int insize)
{
	int n, nbits;
	uint8_t byte;
	uint8_t *outptr = outbuf;

	/* Reset pushbit */
	g_nbits = 0;

	/* Extra preamble for RFM receivers - not needed if only
	 * real FHT devices are listening */
	for (n = 0; n < 4; n++)
		*outptr++ = 0xaa;

	/* Fill FIFO bit-by-bit to simulate 400us/600us OOK protocol */
	for (n = 0; n < 12; n++)
		pushbit(0,&outptr);
	pushbit(1,&outptr);
	for (n = 0; n < 6; n++) {
		int parity = 0;
		byte = inbuf[n];
		for (nbits = 0; nbits < 8; nbits++) {
			pushbit(byte & 0x80,&outptr);
			parity ^= (byte / 0x80);
			byte <<= 1;
		}
		pushbit(parity,&outptr);
	}
	pushbit(0,&outptr);
	pushbit(0,&outptr);

	return outptr - outbuf + 1;
}

/*!
 * Decode a buffer from FHT pulse width encoding into
 * actual byte values.  TODO: Check parity
 */
static int fht_rfm_decode(uint8_t *inbuf, uint8_t *outbuf, int outsize)
{
	int inbits = 0, outbits = 0;
	int synced = 0;
	uint8_t symbol;
	uint16_t outbyte = 0;

	while (outsize) {
		/* Get next undecoded 8 bits from input buffer */
		symbol = (inbuf[0] << inbits) | (inbuf[1] >> (8 - inbits));

		/* Look for valid symbol (left-justified) */
		if ((symbol & 0xf0) == 0xc0) {
			/* zero bit */
			outbyte = outbyte << 1;
			inbits += 4;
		} else if ((symbol & 0xfc) == 0xe0) {
			/* one bit */
			outbyte = (outbyte << 1) | 1;
			inbits += 6;
		} else {
			/* invalid bit pattern */
			DPRINTF("Invalid bit pattern - abort\n");
			return -1;
		}

		/* Step input */
		if (inbits >= 8) {
			inbits -= 8;
			inbuf++;
		}

		/* Don't start shifting bits out until after we have seen the first
		 * 1 bit at the end of the preamble */
		if (!synced) {
			if (outbyte & 1)
				synced = 1;
			continue;
		}

		/* Step output */
		if (++outbits == 9) {
			*outbuf++ = (outbyte >> 1); /* remove parity bit */
			outsize--;
			outbits = 0;
		}
	}

	return 0;
}

#define FHT_BUFFER_SIZE	64

static void fht_transmit(void)
{
	uint8_t *_msg = (uint8_t*)&g_message;
	int n, length;
	/* Output buffer for variable length bitstream
	 * The preamble is always 54 actual bits long (12 0's and a 1)
	 * The payload is 54 bits - maximum actual length = 54x6 = 324 bits
	 * Terminates with two 0's = 8 bits
	 * Maximum buffer size therefore = 49 bytes + 4 for extra preamble
	 */
	uint8_t outbuf[FHT_BUFFER_SIZE];

	/* Clear output buffer */
	memset(outbuf, 0, FHT_BUFFER_SIZE);

	/* Calculate checksum */
	g_message.checksum = 0x0c;
	for (n = 0; n < 5; n++) {
		g_message.checksum += _msg[n];
	}

	/* Dump un-encoded message */
	hexdump(_msg, sizeof(fht_msg_t));

	/* Dump encoded message */
	length = fht_rfm_encode(_msg, outbuf, sizeof(fht_msg_t));
	hexdump(outbuf, length);

	/* Transmit twice */
	si443x_transmit(outbuf, length);
	/* This delay is about right with debug enabled.  The actual gap
	 * should be about 8 ms */
	_delay_ms(5);
	si443x_transmit(outbuf, length);
}

/* Called once every 500 ms from ISR */
void fht_tick(void)
{
	/* Transmit slot depends on HC2 byte */
	int slot = g_message.hc2 & 7;

	if ((g_message.command & 0xf) == FHT_SYNC) {
		/* Sync message is sent once per second for 2 minutes */
		if (g_slot_count & 1) {
			/* transmit sync */
			DPRINTF("%u sync %d\n", g_ticks, g_slot_count);
			g_message.extension = g_slot_count;
			fht_transmit();
		}
		if (--g_slot_count < 3) {
			/* We don't send the '0' sync count - we are now at 4 seconds before
			 * the first slot */
			g_slot_count = PERIOD_BASE - 8;

			/* First actual message - will be sent when the correct timeslot is reached */
			g_message.command = FHT_EXT_PRESENT | FHT_SYNC_SET;
			g_message.extension = 0;
		}
	} else {
		g_slot_count++;
		if (g_slot_count == PERIOD_BASE + slot) {
			/* This is our timeslot - send the stored message */
			DPRINTF("%u slot %d tx\n", g_ticks, slot);
			g_slot_count = 0;
			fht_transmit();

			/* Set the repeat flag for next time */
			g_message.command |= FHT_REPEAT;
		}
	}

	g_ticks++;
}

void fht_enqueue(uint8_t address, uint8_t command, uint8_t value)
{
	cli();
	g_message.address = address;
	g_message.command = FHT_EXT_PRESENT | (command & 0xf);
	g_message.extension = value;
	sei();
}

void fht_sync(uint8_t hc1, uint8_t hc2)
{
	/* Enqueue the sync message.  The interrupt handler will do the rest.  We can
	 * monitor for the command change to see when it has completed */
	cli();
	g_message.hc1 = hc1;
	g_message.hc2 = hc2;
	g_message.address = 0;
	g_message.command = FHT_EXT_PRESENT | FHT_SYNC;
	g_message.extension = 0;
	g_slot_count = SYNC_TICKS | 1;
	sei();

	/* Wait for repeat bit to be set - this indicates that the first real command
	 * has been sent following the sync procedure */
	DPRINTF("Waiting for sync...\n");
	while (!(g_message.command & FHT_REPEAT));
	DPRINTF("Sync complete\n");
}

void fht_receive(void)
{
	fht_msg_t rxmsg;
	uint8_t buf[FHT_BUFFER_SIZE];
	int rssi;

	/* Start receiver, no timeout.  Receive up to 46 bytes, which is
	 * sufficient to capture the longest (all 1s) encoded packet
	 * from the sync point onwards */
	si443x_receive(buf, FHT_BUFFER_SIZE, 0, &rssi);

	DPRINTF("Rx rssi %d dBm\n", rssi);

	/* Dump encoded message */
	hexdump(buf, FHT_BUFFER_SIZE);

	if (fht_rfm_decode(buf, (uint8_t*)&rxmsg, sizeof(rxmsg)) < 0) {
		DPRINTF("Symbol error\n");
	}

	/* Dump decoded message */
	hexdump((uint8_t*)&rxmsg, sizeof(rxmsg));

	/* Decode contents */
	msgdump(&rxmsg);
}

#if 0
void fht_test(void)
{
	fht_msg_t msg;
	uint8_t *_msg = (uint8_t*)&msg, *ptr;
	uint8_t buf[FHT_BUFFER_SIZE];
	int n, length;

	msg.hc1 = 12;
	msg.hc2 = 34;
	msg.address = 0;
	msg.command = FHT_EXT_PRESENT | FHT_VALVE_SET;
	msg.extension = 20;
	msg.checksum = 0x0c;
	for (n = 0; n < 5; n++) {
		msg.checksum += _msg[n];
	}

	DPRINTF("Encoding...\n");
	hexdump((uint8_t*)&msg, sizeof(msg));
	length = fht_rfm_encode((uint8_t*)&msg, buf, sizeof(msg));
	hexdump(buf, length);

	DPRINTF("Decoding...\n");
	memset(&msg, 0, sizeof(msg));
	ptr = &buf[8]; /* Skip preamble and 'sync' */
	length -= 8;
	hexdump(ptr, length);
	fht_rfm_decode(ptr, (uint8_t*)&msg, sizeof(msg));
	hexdump((uint8_t*)&msg, sizeof(msg));
	msgdump(&msg);
}

#endif
